/// <reference types="vite/client" />
import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string

if (!SUPABASE_URL || !SUPABASE_KEY) {
  console.warn('⚠️ PanelFit: Variables de Supabase no configuradas')
}

export const supabase = createClient(SUPABASE_URL || '', SUPABASE_KEY || '')
